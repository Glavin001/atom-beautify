export default {
  data: function () {
    return {
      text: 'Hello, world!'
    }
  }
}
