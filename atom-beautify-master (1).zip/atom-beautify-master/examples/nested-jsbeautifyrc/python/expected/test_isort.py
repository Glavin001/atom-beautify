import os
import sys
from pprint import pprint

from scrapy import FormRequest, Request
