An example of **bold** and *italics*.

Another example of __bold__ and _italics_.
