/* ctest4 */
fm_status fm2000EventHandlingInitialize(fm_int sw);
fm_status fm2000MacTableOverflowStart(fm_int sw);
fm_bool fm2000ProcessMATableEntry(                fm_mac_table_work_list *pWork,
                                                  fm_int sw,
                                                  fm_int index,
                                                  fm_thread *   event_handler,
                                                  fm_uint32 *    numUpdates,
                                                  fm_event **event);
void foo()
{
        Logger log = new Logger();
        Logger log= new Logger( );

        log.foo.bar    = 5;
        log.narf.sweat = "cat";
        for (i = 0; i<5; i++) bar(i);
}
int this_works(int x);
int bug(int); // BUG: left-aligned
typedef int fooman;
enum FLAGS
{
        FLAGS_decimal  = 1,  // decimal
        FLAGS_unsigned = 2, // u or U suffix
        FLAGS_long     = 4, // l or L suffix
};
